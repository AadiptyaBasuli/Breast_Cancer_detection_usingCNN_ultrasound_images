# Ultra S > 2021-09-21 3:38pm
https://universe.roboflow.com/ultrasound/ultra-s

Provided by a Roboflow user
License: CC BY 4.0

